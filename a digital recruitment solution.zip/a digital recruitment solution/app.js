var swiper=new swiper(".mySwiper",{
    loop:true,
    autoplay:{
        dalay:2500,
        disableOnInteraction:false,
    },
    sliderPerView:1,
    spacaBetween:10,
    pagination:{
        el:".swiper-pagination",
        clickable:true,
        
    },
    breakpoints:{
        640:{
            sliderPerView:2,
            spacaBetween:20,
        },
        768:{
            sliderPerView:3,
            spacaBetween:40,
        },
        1024:{
            sliderPerView:3,
            spacaBetween:50,
        }


    }
})